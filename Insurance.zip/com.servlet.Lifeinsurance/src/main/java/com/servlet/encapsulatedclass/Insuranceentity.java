package com.servlet.encapsulatedclass;

public class Insuranceentity {
	
	private String policycode;
	private String policyname;
	private String policytype;
	private String policysubtype;
	private String annualpremiumrange;
	private String eligiblityage;
	private String keybenefits;
	public String getPolicycode() {
		return policycode;
	}
	public void setPolicycode(String policycode) {
		this.policycode = policycode;
	}
	public String getPolicyname() {
		return policyname;
	}
	public void setPolicyname(String policyname) {
		this.policyname = policyname;
	}
	public String getPolicytype() {
		return policytype;
	}
	public void setPolicytype(String policytype) {
		this.policytype = policytype;
	}
	public String getPolicysubtype() {
		return policysubtype;
	}
	public void setPolicysubtype(String policysubtype) {
		this.policysubtype = policysubtype;
	}
	public String getAnnualpremiumrange() {
		return annualpremiumrange;
	}
	public void setAnnualpremiumrange(String annualpremiumrange) {
		this.annualpremiumrange = annualpremiumrange;
	}
	public String getEligiblityage() {
		return eligiblityage;
	}
	public void setEligiblityage(String eligiblityage) {
		this.eligiblityage = eligiblityage;
	}
	public String getKeybenefits() {
		return keybenefits;
	}
	public void setKeybenefits(String keybenefits) {
		this.keybenefits = keybenefits;
	}
	

}
