package com.servlet.encapsulatedclass;

public class LoansEntity {

	private String policyname;
	private String Typeofloan;
	private String intrest;
	private String amountsecured;
	private String age;
	public String getPolicyname() {
		return policyname;
	}
	public void setPolicyname(String policyname) {
		this.policyname = policyname;
	}
	public String getTypeofloan() {
		return Typeofloan;
	}
	public void setTypeofloan(String typeofloan) {
		Typeofloan = typeofloan;
	}
	public String getIntrest() {
		return intrest;
	}
	public void setIntrest(String intrest) {
		this.intrest = intrest;
	}
	public String getAmountsecured() {
		return amountsecured;
	}
	public void setAmountsecured(String amountsecured) {
		this.amountsecured = amountsecured;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	
	
}
